<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Setting;
use App\Faq;
use App\FaqCategory;
use App\Location;
use Session;
use Mail;

class AskController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $settings = Setting::where('status', '1')->get();
        $categories = FaqCategory::where('status', '1')->get();
        $locations = Location::where('status', '1')->get();

        return view('ask', compact('settings', 'categories', 'locations'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function sendMail(Request $request)
    {

        $settings = Setting::where('status', '1')->get();

        if(count($settings) == 1){

            foreach ($settings as $setting ){
                $sendTo = $setting->contact_mail;
                $appName = $setting->title;
            }

            // Field Validation
            $request->validate([
                'name' => 'required|max:250',
                'email' => 'required|max:250',
                'category' => 'required',
                'location' => 'required',
                'question' => 'required',
            ]);


            // Insert Data
            $data = new Faq;
            $data->asked_by = $request->name;
            $data->email = $request->email;
            $data->category_id = $request->category;
            $data->location_id = $request->location;
            $data->question = $request->question;
            $data->status = 2;
            $data->save();


            /*// Passing data to email template
            $data['name'] = $request->name;
            $data['email'] = $request->email;
            $data['phone'] = $request->phone;
            $data['msg_body'] = $request->message;

            // Mail Information
            $senderName = $request->name;;
            $sendFrom = $request->email;
            $subject = $request->subject;

            // Send Mail
            Mail::send('emails.email', $data, function($message) use ($sendTo, $senderName, $sendFrom, $appName, $subject) {

                // Mail Information
                $message->from($sendFrom, $senderName);
                $message->to($sendTo, $appName)
                        ->subject($subject);

            });*/

            
            Session::flash('success', 'Mail Send Successfully!');

        }
        else{
            Session::flash('error', 'Receiver not configured!');
        }

        

        return redirect()->back();

    }
}
